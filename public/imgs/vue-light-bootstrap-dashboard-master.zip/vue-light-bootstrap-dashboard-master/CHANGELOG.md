# Change Log

## [2.0.0] 2019-02-14
 - Update to Bootstrap 4
 - Update to Vue CLI 3
 - Several UI fixes & improvements
 - Cleanup and simplify code structure
 - Add pwa support
  
## [1.0.0] 2017-06-18
### Stable Original Release
